enum Logical {False, True};
void load_board(const char* filename, char board[9][9]);
void display_board(const char board[9][9]);
Logical is_complete(const char board[9][9]);
Logical make_move(const char position[], const char digit, char board[9][9]);
Logical save_board(const char document[], const char board[9][9]);
Logical solve_board(char board[9][9]);
Logical counter(char board[9][9], int& counter_value);
