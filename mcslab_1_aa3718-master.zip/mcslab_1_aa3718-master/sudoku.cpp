#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cassert>
#include <chrono>
#include "sudoku.h"

using namespace std;

/* You are pre-supplied with the functions below. Add your own 
   function definitions to the end of this file. */

/* pre-supplied function to load a Sudoku board from a file */
void load_board(const char* filename, char board[9][9]) {

  cout << "Loading Sudoku board from file '" << filename << "'... ";

  ifstream in(filename);
  if (!in)
    cout << "Failed!" << endl;
  assert(in);

  char buffer[512];

  int row = 0;
  in.getline(buffer,512);
  while (in && row < 9) {
    for (int n=0; n<9; n++) {
      assert(buffer[n] == '.' || isdigit(buffer[n]));
      board[row][n] = buffer[n];
    }
    row++;
    in.getline(buffer,512);
  }

  cout << ((row == 9) ? "Success!" : "Failed!") << endl;
  assert(row == 9);
};

/* internal helper function */
void print_frame(int row) {
  if (!(row % 3))
    cout << "  +===========+===========+===========+" << endl;
  else
    cout << "  +---+---+---+---+---+---+---+---+---+" << endl;
};

/* internal helper function */
void print_row(const char* data, int row) {
  cout << (char) ('A' + row) << " ";
  for (int i=0; i<9; i++) {
    cout << ( (i % 3) ? ':' : '|' ) << " ";
    cout << ( (data[i]=='.') ? ' ' : data[i]) << " ";
  }
  cout << "|" << endl;
};

/* pre-supplied function to display a Sudoku board */
void display_board(const char board[9][9]) {
  cout << "    ";
  for (int r=0; r<9; r++) 
    cout << (char) ('1'+r) << "   ";
  cout << endl;
  for (int r=0; r<9; r++) {
    print_frame(r);
    print_row(board[r],r);
  }
  print_frame(9);
};

/* add your functions here */

// Boolean function type Logical returning true if board is full or false if it is not
Logical is_complete(const char board[9][9]) {
  /* Goes through a row and column for loop and returns false if value of specific board space is a period, and if not it goes through the entire board till it exits for loop and retruns true */
  for (int row = 0; row < 9 ; row++){
       for (int column = 0; column < 9; column++) {
      if (board[row][column] != '.') {
      } else {
	return False;
      };   
    };
  };
  return True;
};

/* Boolean function type Logical returning either true if it's a right move and filling in baord or false if it isn't  */ 
Logical make_move(const char position[], const char digit, char board[9][9])
{
  // Converts position type character to integer thanks to ASCII code table 
int row_base = 65;
int row_character = position[0];
int row_final = (row_character - row_base);

/* Converts position type character to integer thanks to ASCII code table and substracts one as the board array includes values 0 to 8 */
int column_base = 48;
int column_character = position[1];
int column_final = (column_character - column_base) - 1;
 
//Check row for same digit                                                             
 for (int column_check =0 ; column_check < 9 ; column_check++) {
   if (column_check != column_final){
char current_column = board[row_final][column_check];
 if (current_column == digit){
   return False;
 };
 };
 };

// Check column for same digit                                                         
for (int row_check =0 ; row_check < 9 ; row_check++) {
  if (row_check != row_final){
    char current_row = board[row_check][column_final];
    if (current_row == digit){
      return False;
    };
  };
 };


// Check the quardrent for same digit

// Get first column value of quadrant by dividing the column by three and due to rouding assigning it to the right quadrant
 int col_first = 0;
  int* pointer_col_first = &col_first;
 if (column_final/3 == 0) {
   *pointer_col_first = 0;
 };

 if (column_final/3 == 1) {
   *pointer_col_first = 3;
 };

 if (column_final/3 == 2) {
    *pointer_col_first = 6;
 };

 
// Get first row value of quadrant by dividing the row by three and due to rouding assigning it to the right quadrant
 int row_first = 0;
 int* pointer_row_first = &row_first;
 if (row_final/3 == 0) {
   *pointer_row_first = 0;
 };

 if (row_final/3 == 1) {
   *pointer_row_first = 3;
 };

 if (row_final/3 == 2) {
   *pointer_row_first = 6;
 };

 // Value of last row to check for value in targeted quadrant
int limit_row = row_first + 3;
int limit_col = col_first + 3;

//Checks that the value in question does not check itself and is not equal to any value in the quadrant and if so inputs the value in board and return true
for (int row = row_first; row < limit_row; row++) {
       if (row_final != row) {
	 for (int column = col_first ; column < limit_col; column++) {
	   if (column_final != column) {
	     if (board[row][column] == digit){ 
	       return False;
	       };
	 };
       };
 };
 };
 board[row_final][column_final] = digit;
 return True;

};

/* Boolean function type Logical returning either true if file outputed correclty or false if it hasn't  */  
Logical save_board(const char document[], const char board[9][9]) {
  ofstream out_stream;
  out_stream.open(document);

  if (!out_stream.fail()) {
  for (int row = 0; row < 9 ; row++) {
    for (int column = 0; column <9 ; column++) {
      char character = board[row][column]; 
      out_stream << character;
    };
    out_stream << "\n";
  };
  out_stream.close();


  return True;
  } else {
    return False;
  };
};

/* Boolean function type Logical returning either true if entire board is solved or false if it is deemed unsolvable */
Logical solve_board(char board[9][9]) {
  for (int row = 0; row < 9 ; row++) {
    for (int column = 0; column < 9 ; column++) {
      if (board[row][column] == '.') {
   
  for (char digit = 49 ; digit < 58 ; digit++) {
    char first_array = row + 65;
    char second_array = column + 49;
    char array [] = {(first_array) , (second_array)};
    
    /* If the move is right, it will move to next positiion through recursion, if false will set the value back to a period and return false, causing the fuction to go back to previous empty box and try the next correct move */
    
    if (make_move(array, digit, board) && solve_board(board)) {
        return True;
      };
      };
  board[row][column] = '.';
  return False;
      };
      };
  };
  return True;
  };

/* Boolean function type Logical returning either true if board is solved and printing out counter value or false if deemed unsolvable */
Logical counter(char board[9][9], int& counter_value) {
for (int row = 0; row < 9 ; row++) {
    for (int column = 0; column < 9 ; column++) {
      if (board[row][column] == '.') {
   
  for (char digit = 49 ; digit < 58 ; digit++) {
    char first_array = row + 65;
    char second_array = column + 49;
    char array [] = {(first_array) , (second_array)};
    if (make_move(array, digit, board) && counter(board, counter_value)) {
        return True;
      };
      };
  /* Counter variable increase each type a square has no solutions, causing the function to go back and change previous value */
  counter_value++;
  board[row][column] = '.';
  return False;
      };
      };
  };
 cout << counter_value << "\n";
  return True;
  };



	        
